# Türkiye Gezi Rehberi (telefon uygulaması)

Tek sayfalık, internetsiz de çalışabilen bir web uygulaması. Harita, liste, özet; şehirlerin altına yer ekleme; Excel olarak gönderme.

## GitHub'a yükleme (bilgisayardan, komut yok)
1. github.com → sağ üstte **+ → New repository**. Ad: `gezi-rehberi`, **Public** seç, Create.
2. **uploading an existing file** bağlantısına tıkla; bu klasördeki dosyaların hepsini sürükle (index.html, sw.js, manifest.webmanifest, icon.svg, icon-192.png, icon-512.png). **Commit changes**.
3. **Settings → Pages → Build and deployment**: Source = *Deploy from a branch*, Branch = `main` / `(root)` → Save.
4. 1-2 dakika sonra adres hazır: `https://KULLANICI-ADIN.github.io/gezi-rehberi/`

## Telefona kurma
- iPhone: adresi Safari'de aç → Paylaş → **Ana Ekrana Ekle**
- Android: Chrome'da aç → ⋮ → **Ana ekrana ekle / Uygulamayı yükle**

## Notlar
- Yaptığın işaretlemeler ve eklediklerin **telefonun tarayıcısında** saklanır (GitHub'a gitmez). Menü (⋮) → *Yedek al* ile JSON yedeği alabilirsin.
- Excel: Menü (⋮) → *Excel olarak gönder*. Telefonun paylaşım menüsü açılır; Mail'i seç, dosya ek olarak gelir.
- İl haritası ilk açılışta internetten yüklenir, sonra telefonda saklanır. Kendi harita dosyanı kullanmak istersen GeoJSON'u `harita/tr.json` olarak repoya ekle.
